package mueller;

import java.util.Stack;

/**
 * @author max
 * @version Nov 23, 2015
 * 
 */
public class BrikettStack extends Stack<Brikett>{}
