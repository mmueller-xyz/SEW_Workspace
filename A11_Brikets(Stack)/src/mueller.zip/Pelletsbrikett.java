package mueller;

public class Pelletsbrikett extends Brikett {
	/**
	 * @return
	 * @since Nov 23, 2015
	 */
	@Override
	public String toString() {
		return getClass().getName();
	}
}